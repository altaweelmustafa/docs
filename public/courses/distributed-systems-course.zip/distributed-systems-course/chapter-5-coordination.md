---
title: "Chapter 5 – Coordination"
date: 2026-07-03
description: "Clock synchronization, logical clocks, vector clocks, mutual exclusion, ZooKeeper, election algorithms, gossip-based coordination, secure publish-subscribe, and location systems."
tags: [distributed-systems, coordination, clocks, mutual-exclusion, elections, zookeeper, gossip, location]
toc: true
weight: 4
---

## Coordination in Distributed Systems

> Coordination is about getting independent machines to agree on time, ordering,
> access to shared resources, leadership, membership, and shared state.

Coordination is hard because distributed systems usually do not have a perfect
global clock, communication can be delayed, and processes can fail independently.

---

## Physical Clocks

Sometimes a system needs real time, not only event ordering. Physical clock
synchronization tries to keep machine clocks close to each other or close to UTC.

UTC is based on highly accurate atomic clocks and can be broadcast through radio
or satellite.

---

## Precision and Accuracy

| Term | Meaning |
|---|---|
| Precision | How close two machine clocks are to each other |
| Accuracy | How close a machine clock is to real UTC time |
| Internal synchronization | Keep clocks precise relative to each other |
| External synchronization | Keep clocks accurate relative to real time |

A system may have clocks that agree with each other but are all wrong compared
to real time. That is precise but not accurate.

---

## Clock Drift

Clock drift happens because hardware clocks do not tick at exactly the same rate.

A clock may be:

- Fast.
- Perfect.
- Slow.

Clock synchronization algorithms must account for drift and adjust clocks before
they move too far apart.

---

## Time Servers and NTP Idea

A client can ask a time server for the current time. The challenge is that the
request and response take time to travel through the network.

The client estimates:

| Value | Meaning |
|---|---|
| Offset | How far the client clock is from the server clock |
| Delay | Approximate network delay of the exchange |

Network Time Protocol collects offset and delay pairs and prefers the offset
associated with the smallest delay.

---

## Reference Broadcast Synchronization

Reference Broadcast Synchronization, or RBS, uses a reference message broadcast
to multiple receivers.

The idea is:

- A node broadcasts a reference message.
- Each receiver records the local time when the message arrived.
- Receivers compare their recorded times.
- Linear regression can be used to model clock drift over time.

RBS focuses on receiver-to-receiver synchronization instead of sender-to-receiver
synchronization.

---

## Logical Clocks

Often the exact physical time is less important than the order of events.
Logical clocks provide ordering without requiring a global physical clock.

The key relation is **happened-before**.

| Rule | Meaning |
|---|---|
| Same process | If event `a` occurs before event `b` in the same process, then `a → b` |
| Message passing | Sending a message happens before receiving that message |
| Transitivity | If `a → b` and `b → c`, then `a → c` |

This gives a partial ordering of events in a distributed system.

---

## Lamport Logical Clocks

Lamport clocks attach a timestamp to each event so the timestamps respect the
happened-before relation.

Each process keeps a counter.

Rules:

1. Before each local event, increment the local counter.
2. When sending a message, attach the current counter value.
3. When receiving a message, set the local counter to the maximum of the local
   counter and the received timestamp, then increment it.

Lamport clocks guarantee that if `a → b`, then `C(a) < C(b)`. However, the
reverse is not always true: `C(a) < C(b)` does not prove that `a` caused `b`.

---

## Totally Ordered Multicast

Totally ordered multicast ensures that all replicas deliver updates in the same
order.

This is important when concurrent updates can lead to different final values.
For example, if one process adds money and another process applies interest,
replicas must perform the operations in the same order.

Basic idea:

- Each message is timestamped.
- Each process stores incoming messages in a local queue ordered by timestamp.
- Messages are acknowledged.
- A message is delivered only when it is safe to know that no smaller timestamped
  message will arrive later.

---

## Vector Clocks

Vector clocks improve on Lamport clocks by capturing potential causality.

Each process keeps a vector. If there are `N` processes, each timestamp has `N`
entries.

| Entry | Meaning |
|---|---|
| `VCi[i]` | Number of events known from process `Pi` itself |
| `VCi[j]` | Number of events from process `Pj` known by process `Pi` |

Rules:

1. Before executing an event, increment the local vector entry.
2. When sending a message, attach the whole vector.
3. When receiving a message, take the element-wise maximum with the received
   vector, then update the local entry.

Vector clocks can tell whether one event may causally precede another or whether
two events are concurrent.

---

## Causally Ordered Multicast

Causally ordered multicast delivers a message only after all messages that could
causally precede it have already been delivered.

For a message from process `Pi`, a receiver `Pj` delays delivery until:

- The message is the next expected message from `Pi`.
- All other vector-clock entries are not ahead of what `Pj` already knows.

This prevents an effect from being delivered before its possible cause.

---

## Mutual Exclusion

Mutual exclusion is needed when several processes want exclusive access to a
shared resource.

Two main approaches are:

| Approach | Meaning |
|---|---|
| Permission-based | A process must get permission before entering the critical region |
| Token-based | A process may enter only when it holds a token |

---

## Centralized Mutual Exclusion

A simple approach is to use one coordinator.

Steps:

1. A process asks the coordinator for permission.
2. If the resource is free, the coordinator grants permission.
3. If the resource is busy, the coordinator delays the reply.
4. When the current process releases the resource, the coordinator grants access
   to the next waiting process.

This is simple, but the coordinator can become a bottleneck or point of failure.

---

## Ricart and Agrawala Algorithm

Ricart and Agrawala is a distributed permission-based algorithm.

A process replies to another process's request only if:

- It has no interest in the shared resource, or
- It also wants the resource but the requester has higher priority according to
  timestamps.

Otherwise, the reply is deferred.

The algorithm avoids a central coordinator, but it requires many messages.

---

## Token Ring Algorithm

In the token ring algorithm, processes are organized in a logical ring.

- The token circulates around the ring.
- A process may enter the critical region only when it has the token.
- If it does not need the resource, it passes the token to the next process.

The algorithm is simple, but losing the token or a node failure requires recovery.

---

## Decentralized Mutual Exclusion

In decentralized mutual exclusion, the resource is replicated and each replica
has a coordinator.

A process needs a majority vote from coordinators before entering the critical
region.

This reduces dependence on one coordinator, but correctness depends on how many
coordinators fail or forget granted permissions.

---

## Comparing Mutual Exclusion Algorithms

| Algorithm | Main Advantage | Main Disadvantage |
|---|---|---|
| Centralized | Simple and low message count | Coordinator bottleneck/failure |
| Ricart and Agrawala | No central coordinator | Many messages and deferred replies |
| Token ring | Simple permission rule | Token loss and ring maintenance |
| Decentralized voting | More fault tolerant than one coordinator | More complex correctness analysis |

---

## ZooKeeper and Locks

ZooKeeper provides a tree-based namespace similar to a file system. Clients can
create, delete, update, and check nodes.

A simple lock can be represented by a node such as `/lock`.

Possible race condition:

1. Client `C1` creates `/lock`.
2. Client `C2` wants the lock and sees that `/lock` exists.
3. Before `C2` subscribes to changes, `C1` deletes `/lock`.
4. `C2` then subscribes and waits, even though the lock was already released.

Version numbers and notification mechanisms help avoid this race.

---

## Election Algorithms

Election algorithms select a coordinator dynamically.

Basic assumptions often include:

- Each process has a unique ID.
- Processes know the IDs of other processes.
- The goal is to elect the highest-ID process that is still alive.

---

## Bully Algorithm

In the bully algorithm, if a process notices that the coordinator is not
responding, it starts an election.

Steps:

1. It sends election messages to all processes with higher IDs.
2. If no higher process responds, it becomes coordinator.
3. If a higher process responds, that process takes over the election.

The highest live process eventually becomes coordinator.

---

## Ring Election Algorithm

In a ring election algorithm:

- Processes are arranged in a logical ring.
- A process sends an election message to its successor.
- Each live process adds itself to the list.
- When the message returns to the initiator, the process with highest priority is
  elected.
- A coordinator message is sent around the ring.

---

## Leader Election in ZooKeeper and Raft

ZooKeeper-style leader election considers both server identity and transaction
freshness. A server with more up-to-date transaction information may be preferred.

Raft uses terms and server states:

| State | Meaning |
|---|---|
| Follower | Waits for leader messages |
| Candidate | Starts an election when no leader heartbeat is received |
| Leader | Sends regular heartbeats and manages the group |

A candidate becomes leader after receiving votes from a majority.
Different timeout values help avoid repeated simultaneous elections.

---

## Gossip-Based Coordination

Gossip can also be used for coordination tasks.

Examples include:

| Use | Meaning |
|---|---|
| Data dissemination | Spread updates through peer exchanges |
| Aggregation | Compute values such as averages over many nodes |
| Peer sampling | Let nodes obtain random peers without knowing the whole network |
| Overlay construction | Build structured neighbor relationships through local exchanges |

In aggregation, if two nodes gossip and have values `vi` and `vj`, both can set
their values to `(vi + vj) / 2`. Eventually, nodes converge toward the global
average.

---

## Secure Gossiping

Gossip systems can be attacked. In a hub attack, colluding nodes return links
only to each other, causing many benign nodes to point only to attackers.

One defense is gathering statistics about indegree distributions. If attackers do
not know whether a response will be used for normal operation or measurement,
they are pressured to follow the protocol.

---

## Distributed Event Matching

In publish-subscribe systems:

- A subscriber states which events it is interested in.
- A publisher sends a notification.
- The system checks whether the notification matches the subscription.

The hard part is implementing matching in a scalable way.

Selective routing can forward notifications only to relevant nodes instead of
broadcasting everything.

---

## Secure Publish-Subscribe

Secure publish-subscribe is difficult because publishers and subscribers may need
mutual anonymity.

Challenges include:

- A secure channel may not be possible if parties do not know each other.
- Message integrity is harder when the source is hidden.
- A trusted broker may not be realistic for sensitive data.

One solution is searching over encrypted data, such as using Public-Key Encryption
with Keyword Search, or PEKS.

---

## Location Systems

Large-scale distributed systems often need a notion of distance or proximity.
Location systems estimate where nodes are.

Examples include:

| Method | Idea |
|---|---|
| GPS | Uses satellite signals and timing equations |
| WiFi-based location | Uses known access points and estimated distances |
| Logical positioning | Uses latency or network measurements to compute relative position |

Location is useful for selecting nearby servers, reducing latency, and improving
routing decisions.

---

## Quick Summary

| Concept | Key Idea |
|---|---|
| Physical clock | Measures real time but may drift |
| Logical clock | Orders events without real time |
| Lamport clock | Preserves happened-before ordering |
| Vector clock | Captures possible causality and concurrency |
| Mutual exclusion | Controls exclusive access to shared resources |
| Election algorithm | Dynamically selects a coordinator or leader |
| Gossip coordination | Uses peer exchanges for dissemination, aggregation, and overlays |
| Publish-subscribe | Matches notifications to subscriptions |
| Location system | Estimates node position or proximity |

---
title: "Chapter 1 – Introduction to Distributed Systems"
date: 2026-07-03
description: "Distributed versus decentralized systems, design goals, transparency, openness, dependability, security, scalability, system classifications, and common pitfalls."
tags: [distributed-systems, introduction, transparency, scalability, dependability, security]
toc: true
weight: 1
---

## What Is a Distributed System?

> A distributed system is a networked computer system where processes and
> resources are spread across multiple computers, but they cooperate to provide a
> service.

A useful distinction is between **decentralized** and **distributed** systems.
In a decentralized system, processes and resources are necessarily spread across
multiple computers. In a distributed system, they are spread enough that the
system must handle communication, coordination, failures, and distance as part
of its design.

A system can also look logically centralized while being physically distributed.
For example, a naming service may appear as one service to users, but internally
it can run on many machines.

---

## Two Views of Building Distributed Systems

There are two common ways to think about building distributed systems:

| View | Meaning |
|---|---|
| Integrative view | Connect existing networked systems into one larger system |
| Expansive view | Extend an existing networked system by adding more computers |

The important idea is that adding more machines is not enough. The system must
also deal with communication delays, partial failures, security, and management.

---

## Main Design Goals

Distributed systems are usually designed to achieve four major goals:

| Goal | Meaning |
|---|---|
| Resource sharing | Let users and applications share files, storage, services, devices, or computing power |
| Distribution transparency | Hide the fact that resources are spread over different machines |
| Openness | Make the system easy to integrate, extend, and interoperate with other systems |
| Scalability | Keep the system working well as users, distance, or organizations increase |

---

## Resource Sharing

Resource sharing means that many users or applications can access shared
resources through the network.

Examples include:

- Cloud storage and shared files.
- Shared mail services.
- Shared web hosting.
- Content distribution networks.
- Peer-assisted multimedia streaming.

The slogan **"the network is the computer"** captures the idea that useful
computing power can come from many connected machines, not only one local
machine.

---

## Distribution Transparency

Distribution transparency means hiding distribution details from users or
programs.

| Transparency Type | What It Hides |
|---|---|
| Access transparency | Differences in data representation and access methods |
| Location transparency | Where an object or resource is located |
| Relocation transparency | That a resource may move while being used |
| Migration transparency | That a resource may move to another location |
| Replication transparency | That multiple copies exist |
| Concurrency transparency | That multiple users access the same resource |
| Failure transparency | Failures and recovery of resources |

Transparency is usually implemented in **middleware**, which sits between the
application and the operating system.

---

## Why Full Transparency Is Not Always Good

Full transparency sounds nice, but it can be impossible or too expensive.

Some problems cannot be fully hidden:

- Network latency cannot always be hidden.
- A slow machine can look similar to a failed machine.
- A client may not know whether a server completed an operation before crashing.
- Keeping replicas perfectly consistent requires time and synchronization.
- Full transparency may reduce performance.

Sometimes it is better to expose distribution. For example, location-based
services need to know where users are, and users may need to know that a remote
server is not responding.

---

## Openness

An open distributed system uses clear interfaces so that components can work
with other systems.

A system is open when it supports:

- Well-defined interfaces.
- Interoperability between different systems.
- Portability of applications.
- Easy extension.

A key idea is separating **policy** from **mechanism**.

| Concept | Meaning |
|---|---|
| Policy | The rule or decision, such as what level of secrecy is required |
| Mechanism | The tool used to implement the policy, such as encryption algorithms |

A strict separation gives flexibility, but it can also increase configuration and
management complexity.

---

## Dependability

Dependability means that the system can be trusted to provide correct service.
A component may depend on another component if its correctness relies on that
other component.

| Requirement | Meaning |
|---|---|
| Availability | The system is ready for use |
| Reliability | The system continues delivering correct service |
| Safety | The probability of catastrophic failure is very low |
| Maintainability | Failed parts can be repaired easily |

---

## Failure, Error, and Fault

These three words are related, but they do not mean the same thing.

| Term | Meaning | Example |
|---|---|---|
| Failure | A component does not meet its specification | A program crashes |
| Error | A bad internal state that can lead to failure | A programming bug is triggered |
| Fault | The cause of the error | A design mistake or bad code |

Fault handling includes prevention, tolerance, removal, and forecasting.

---

## Security

A distributed system that is not secure cannot be considered dependable.

Important security goals include:

| Goal | Meaning |
|---|---|
| Confidentiality | Only authorized parties can see information |
| Integrity | Only authorized changes can be made |
| Authentication | Verify the identity of an entity |
| Authorization | Decide whether an authenticated entity has access rights |
| Trust | Expect that another entity will behave in a specific way |

Common mechanisms include symmetric encryption, asymmetric encryption, secure
hashing, and digital signatures.

---

## Scalability

Scalability means the system can grow without breaking or becoming too slow.

There are three main types:

| Scalability Type | Meaning |
|---|---|
| Size scalability | The number of users, processes, or nodes increases |
| Geographical scalability | The distance between nodes increases |
| Administrative scalability | The number of organizations or domains increases |

Many systems handle size scalability, but geographical and administrative
scalability are often harder.

---

## Why Scalability Is Hard

Centralized solutions can run into limits because of:

- CPU capacity.
- Storage capacity.
- Disk transfer rate.
- Network capacity between users and the service.
- Long-distance latency.
- Unreliable WAN links.
- Different administrative policies.

As utilization gets close to 100%, response time can grow very quickly. A system
that looks fine at low load may become unusable when the service is almost fully
busy.

---

## Scaling Techniques

Common scaling techniques include:

| Technique | Idea |
|---|---|
| Hide communication latency | Use asynchronous communication so the client does not wait unnecessarily |
| Move computation | Move work closer to the client or closer to the data |
| Partitioning | Split data or work across multiple machines |
| Replication | Keep multiple copies of data or services |
| Caching | Store frequently used data near the user |

Replication and caching improve performance, but they introduce a major problem:
**consistency**. If one copy changes, the other copies may become outdated.
Keeping all copies perfectly synchronized usually requires global coordination,
which does not scale well.

---

## Types of Distributed Systems

Distributed systems can be classified into several major groups.

| Type | Description | Examples |
|---|---|---|
| High-performance distributed computing | Uses many machines to solve large computational problems | Cluster computing, grid computing, cloud infrastructure |
| Distributed information systems | Integrates applications and data across organizations | Transaction processing, enterprise application integration, middleware |
| Pervasive systems | Systems with small, mobile, or embedded devices | Ubiquitous computing, mobile computing, sensor networks |

---

## High-Performance Distributed Computing

High-performance distributed computing includes systems such as clusters and
grids.

| System | Main Idea |
|---|---|
| Cluster computing | A group of similar high-end machines connected through a LAN |
| Grid computing | Heterogeneous resources spread across organizations and wide-area networks |
| Cloud computing | Computing resources offered as services, often using virtualization |

Grid systems often use **virtual organizations**, where users from different
administrative domains are grouped for authorization and resource sharing.

---

## Distributed Information Systems

Distributed information systems focus on integrating applications.

Important approaches include:

- File transfer.
- Shared databases.
- Remote Procedure Call, or RPC.
- Message-oriented middleware.
- Enterprise Application Integration.
- Transaction Processing Monitors.

Transactions are important because they aim to provide **ACID** properties:
atomicity, consistency, isolation, and durability.

---

## Pervasive Systems

Pervasive systems blend naturally into the user environment. They often involve
small, mobile, embedded, or battery-powered devices.

| Subtype | Meaning |
|---|---|
| Ubiquitous computing | Continuous interaction between users and devices |
| Mobile computing | Devices move and their location or connectivity changes |
| Sensor and actuator networks | Many simple nodes sense or act on the physical environment |

Mobile devices commonly act as clients of cloud or edge services.

---

## Common Pitfalls

Distributed systems often become complex because designers make false
assumptions.

Common false assumptions include:

- The network is reliable.
- The network is secure.
- The network is homogeneous.
- The topology does not change.
- Latency is zero.
- Bandwidth is infinite.
- Transport cost is zero.
- There is one administrator.

These assumptions are dangerous because distributed systems are affected by
latency, failures, security issues, heterogeneity, and changing environments.

---

## Quick Summary

| Concept | Key Idea |
|---|---|
| Distributed system | Multiple computers cooperate as one system |
| Transparency | Hide distribution details when useful |
| Openness | Use interfaces and mechanisms that support integration |
| Dependability | Keep services available, reliable, safe, and maintainable |
| Security | Protect confidentiality, integrity, identity, and access |
| Scalability | Grow in size, distance, or administration without collapse |
| Pitfalls | Never assume the network is perfect |

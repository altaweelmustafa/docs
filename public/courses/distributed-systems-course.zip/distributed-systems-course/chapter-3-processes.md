---
title: "Chapter 3 – Processes"
date: 2026-07-03
description: "Threads, context switching, virtualization, containers, clients, servers, server clusters, and code migration in distributed systems."
tags: [distributed-systems, processes, threads, virtualization, servers, clients, code-migration]
toc: true
weight: 2
---

## Processes and Threads

> Distributed systems use processes and threads to structure work across many
> machines. Threads are especially useful because they help hide blocking and
> exploit parallelism.

A **processor** executes instructions. A **thread** is a minimal software processor
that runs a sequence of instructions. A **process** is a software processor that
can contain one or more threads.

| Concept | Meaning |
|---|---|
| Processor | Hardware that executes instructions |
| Thread | Minimal execution context for a sequence of instructions |
| Process | Execution environment that may contain one or more threads |

---

## Context Switching

Context switching means stopping one execution and saving enough information to
continue it later.

| Context Type | What It Contains |
|---|---|
| Processor context | Register values such as stack pointer and program counter |
| Thread context | Processor context plus thread state in memory |
| Process context | Thread context plus process-level information such as MMU state |

Thread switching is usually cheaper than process switching because threads in the
same process share the same address space.

---

## Why Use Threads?

Threads are useful for three main reasons:

- **Avoid needless blocking:** if one thread waits for I/O, another thread can run.
- **Exploit parallelism:** threads can run on different cores.
- **Avoid process switching:** a large application can be organized as multiple
  threads instead of multiple processes.

The trade-off is that threads share memory, so programming mistakes can cause
one thread to corrupt data used by another thread.

---

## User-Level and Kernel-Level Threads

There are two main implementation choices.

| Thread Type | Advantage | Disadvantage |
|---|---|---|
| User-level threads | Fast operations inside one process | If the kernel blocks the process, all its user threads may block |
| Kernel-level threads | Kernel can schedule threads independently | Thread operations require kernel involvement |

Some systems combine both by letting kernel threads execute user-level threads.
This tries to get efficiency and proper blocking behavior at the same time, but
it increases complexity.

---

## Threads in Distributed Systems

Threads are very common in distributed clients and servers.

### Client-side use

A web browser can fetch multiple files at the same time. Each blocking request
can run in a separate thread, so the browser can keep displaying content while
other files are still loading.

### Server-side use

A server can use a dispatcher thread to accept incoming requests and worker
threads to handle them. This lets the server continue accepting new clients even
while other requests are blocked on disk, network, or database operations.

---

## Dispatcher/Worker Model

The dispatcher/worker model is a common server structure.

| Component | Role |
|---|---|
| Dispatcher | Receives incoming requests |
| Worker | Handles a request in a separate thread or process |
| Queue | Stores requests waiting for workers |

This model improves parallelism and makes blocking operations easier to handle.

---

## Virtualization

Virtualization mimics the interface of one system on top of another system.
It is important because hardware changes quickly, while software often needs to
keep running for a long time.

Virtualization helps with:

- Portability.
- Code migration.
- Isolation between components.
- Running old software on new hardware.
- Protecting applications from failures or attacks in other components.

---

## Interfaces Used in Virtualization

Virtualization can mimic different kinds of interfaces.

| Interface | Meaning |
|---|---|
| Instruction Set Architecture | Machine instructions, including privileged and general instructions |
| System calls | Services offered by the operating system |
| Library calls / API | Functions offered to applications |

A virtual machine monitor works best when sensitive instructions trap to the
operating system. If they do not, the system may need emulation,
paravirtualization, or instruction rewriting.

---

## Virtual Machines and Containers

Virtual machines and containers both provide isolation, but they do it at
different levels.

| Technology | Main Idea |
|---|---|
| Virtual machine | Runs a guest system on top of a virtual machine monitor |
| Container | Gives processes isolated views of resources while sharing the host OS kernel |

Containers commonly use:

- **Namespaces:** each container gets its own view of identifiers.
- **Union file systems:** file layers are combined, with writes going to the top
  layer.
- **Control groups:** resource usage can be limited.

Containers are lightweight, but because they depend on the host operating system,
migration across heterogeneous systems is harder than it looks.

---

## Cloud Service Types

Virtual machines are heavily used in cloud computing.

| Service Type | Meaning |
|---|---|
| Infrastructure as a Service | Provides basic computing infrastructure such as VMs |
| Platform as a Service | Provides system-level services and deployment platforms |
| Software as a Service | Provides complete applications to users |

IaaS lets a provider rent virtual machines instead of physical machines, giving
customers isolation while allowing the provider to share hardware.

---

## Clients

A client is the part of the system that interacts with users or calls remote
services.

Client-side software often supports distribution transparency:

| Transparency | Client-side Support |
|---|---|
| Access transparency | Client stubs hide remote calls |
| Location transparency | Client software tracks the actual location of a service |
| Migration transparency | Client software adapts when a resource moves |
| Replication transparency | A client stub can call multiple replicas |
| Failure transparency | Client-side code may retry or mask server failures |

Web browsers and virtual desktop environments are examples of networked user
interfaces that make remote applications feel local.

---

## Servers

A server is a process that provides a service for clients. It waits for requests,
handles them, and returns results.

There are two basic server types:

| Server Type | Behavior |
|---|---|
| Iterative server | Handles one request completely before accepting the next |
| Concurrent server | Uses threads or processes to handle multiple requests at once |

Concurrent servers are the norm because distributed systems often involve
blocking operations, such as disk access or communication with other services.

---

## Out-of-Band Communication

Sometimes a server needs to be interrupted while it is handling a request.
This is called out-of-band communication.

Possible solutions include:

- Use a separate port for urgent messages.
- Use a separate thread or process for urgent data.
- Use transport-layer support such as TCP urgent data.
- Use operating-system signaling techniques.

---

## Stateless and Stateful Servers

| Server Type | Meaning | Advantage | Disadvantage |
|---|---|---|---|
| Stateless server | Does not remember client state after each request | Simpler recovery and fewer inconsistencies | May lose performance opportunities |
| Stateful server | Keeps information about clients | Can improve performance through caching or prefetching | More state must be recovered after failures |

Stateful servers can be very fast when clients cache data, but the system must
handle consistency and recovery carefully.

---

## Object Servers

An object server hosts objects and handles remote invocations on them.
Important design questions include:

- Where is the object code stored?
- Where is the object data stored?
- Which threading model is used?
- Should modified object state be kept?

An **object adapter** implements an activation policy for objects.

---

## Server Clusters

A server cluster uses multiple servers to provide one service.

A common organization has three tiers:

| Tier | Role |
|---|---|
| First tier | Dispatches requests to the correct server |
| Middle tier | Runs application logic |
| Back-end tier | Stores data or provides persistent services |

The first tier can become a bottleneck, so techniques such as request dispatching,
TCP handoff, DNS redirection, and content delivery networks may be used.

---

## Code Migration

Code migration means moving code, data, or execution state to another machine.

Reasons for code migration include:

- Load distribution.
- Moving computation closer to data.
- Reducing communication.
- Dynamic configuration.
- Privacy and legal restrictions, where data cannot be moved but code can.

An example is federated machine learning, where models or code move toward data
instead of collecting private data in one place.

---

## Weak and Strong Mobility

| Mobility Type | What Moves | Meaning |
|---|---|---|
| Weak mobility | Code and data | Execution restarts at the destination |
| Strong mobility | Code, data, and execution state | Execution continues from the migrated state |

Weak mobility is simpler. Strong mobility is more powerful, but it is difficult
because process and thread state depend on hardware, operating systems, and
runtime environments.

---

## Migration in Heterogeneous Systems

Migration is hard when source and target machines are different.

Problems include:

- Different instruction sets.
- Different operating systems.
- Different process or thread contexts.
- Different runtime environments.

A common solution is to use an abstract machine, such as an interpreter, virtual
machine, or virtual machine monitor.

---

## Quick Summary

| Concept | Key Idea |
|---|---|
| Thread | Lightweight execution unit inside a process |
| Context switch | Save execution state and switch to another execution |
| Multithreading | Helps hide blocking and exploit parallelism |
| Virtualization | Mimics interfaces to improve portability and isolation |
| Container | Lightweight isolation using the host OS kernel |
| Client | Uses remote services and hides distribution details |
| Server | Provides services to clients |
| Code migration | Moves code closer to work, data, or better resources |

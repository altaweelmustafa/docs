---
title: "Distributed Systems"
date: 2026-07-03
description: "Distributed systems concepts: design goals, processes, communication, coordination, clocks, mutual exclusion, elections, gossip, and location systems."
tags: [distributed-systems, processes, communication, coordination, middleware]
toc: true
weight: 3
---

## Course Overview

> Distributed systems are systems where processes and resources are spread across
> multiple computers, but the system should still feel usable, reliable, and
> understandable to users and applications.

This course introduces the main building blocks of distributed systems: why we
build them, how processes communicate, how servers and clients are structured,
and how independent machines coordinate without a single perfect global clock.

---

## Chapters Included

| Chapter | Topic | Main Focus |
|---|---|---|
| Chapter 1 | Introduction | Design goals, transparency, scalability, dependability, security, and system types |
| Chapter 3 | Processes | Threads, virtualization, clients, servers, clusters, and code migration |
| Chapter 4 | Communication | Layered protocols, RPC, sockets, message queues, AMQP, multicast, and gossip |
| Chapter 5 | Coordination | Clock synchronization, logical clocks, mutual exclusion, elections, gossip coordination, publish-subscribe, and location systems |

---

## How to Study This Course

Start with the design goals in Chapter 1, because they explain what distributed
systems try to achieve. Then move to processes and communication, because they
show how the system is built. Finally, study coordination, because it explains
how machines agree on ordering, access, leaders, and shared behavior.

---

## Quick Summary

| Area | Big Question |
|---|---|
| Introduction | Why are distributed systems difficult to design correctly? |
| Processes | How do clients, servers, threads, and virtual machines run distributed work? |
| Communication | How do distributed components exchange information? |
| Coordination | How do independent machines agree on time, order, locks, and leaders? |

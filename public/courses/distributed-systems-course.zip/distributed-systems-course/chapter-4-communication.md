---
title: "Chapter 4 – Communication"
date: 2026-07-03
description: "Layered protocols, middleware, communication types, RPC, sockets, ZeroMQ, message queues, AMQP, multicast, and gossip-based data dissemination."
tags: [distributed-systems, communication, rpc, sockets, message-queues, multicast, gossip]
toc: true
weight: 3
---

## Communication in Distributed Systems

> Distributed systems are built from components that run on different machines.
> Communication is the way those components exchange requests, replies, events,
> updates, and coordination messages.

Communication can happen at a low level through sockets, or at a higher level
through middleware, RPC, queues, publish-subscribe systems, or multicast.

---

## Layered Protocols

Traditional networking uses layers such as physical, data link, network,
transport, and application layers.

| Layer | Main Role |
|---|---|
| Physical | Transmits bits between sender and receiver |
| Data link | Groups bits into frames and handles local error or flow control |
| Network | Routes packets through a network |
| Transport | Provides communication facilities such as TCP or UDP |
| Application | Implements application-specific protocols |

For many distributed systems, the transport layer is where practical
communication begins.

---

## TCP and UDP

| Protocol | Type | Meaning |
|---|---|---|
| TCP | Connection-oriented | Reliable, stream-oriented communication |
| UDP | Datagram-oriented | Best-effort communication without reliability guarantees |

TCP is useful when reliable ordered data is needed. UDP is useful when the
application can tolerate loss or wants lower overhead.

---

## Middleware

Middleware provides common services above the operating system and network.

Middleware may provide:

- Communication protocols.
- Marshaling and unmarshaling of data.
- Naming protocols.
- Security protocols.
- Replication and caching mechanisms.
- Scaling support.

The goal is to keep application code simpler by hiding repeated distributed
systems concerns.

---

## Types of Communication

Two important distinctions are used.

| Distinction | Options |
|---|---|
| Lifetime of message | Transient or persistent |
| Waiting behavior | Asynchronous or synchronous |

### Transient vs Persistent

| Type | Meaning |
|---|---|
| Transient communication | If a message cannot be delivered immediately, it may be discarded |
| Persistent communication | The message is stored until it can be delivered |

### Synchronous vs Asynchronous

| Type | Meaning |
|---|---|
| Synchronous communication | Sender waits for delivery, processing, or reply |
| Asynchronous communication | Sender continues without waiting for immediate completion |

---

## Client/Server Communication

Classic client/server communication is usually transient and synchronous.

This means:

- Client and server must both be active.
- The client sends a request and blocks until a reply arrives.
- The server waits for incoming requests and processes them.

Drawbacks include:

- The client cannot do other work while waiting.
- Failures must be handled immediately.
- The model does not fit applications such as mail, news, or event systems.

---

## Message-Oriented Middleware

Message-oriented middleware supports persistent asynchronous communication.

The basic idea is:

- Processes send messages to queues.
- The sender does not need to wait for the receiver.
- Middleware stores messages and may provide fault tolerance.
- Sender and receiver can be decoupled in time and location.

---

## Remote Procedure Call, RPC

RPC tries to make remote communication look like a normal procedure call.

The main idea is that a client calls a local stub. The stub packages the request
into a message, sends it to the server, receives the reply, unpacks it, and
returns the result to the client.

---

## Basic RPC Steps

| Step | Action |
|---|---|
| 1 | Client calls the client stub |
| 2 | Stub builds a message and calls the local OS |
| 3 | Client OS sends the message to the server OS |
| 4 | Server OS gives the message to the server stub |
| 5 | Server stub unpacks parameters and calls the server procedure |
| 6 | Server procedure returns a result |
| 7 | Server stub builds the reply message |
| 8 | Reply is sent back to the client |
| 9 | Client stub unpacks the result |
| 10 | Client receives the result as if it came from a local call |

RPC hides communication, but it cannot hide all distribution problems.

---

## Parameter Passing in RPC

Parameter passing is harder in RPC than in local procedure calls.

Problems include:

- Client and server may use different byte ordering.
- Basic data types may be represented differently.
- Complex data structures must be encoded correctly.
- Passing references to remote memory is not like passing local references.

RPC often uses **copy-in/copy-out** semantics. Remote reference mechanisms can
improve access transparency, but full transparency is still difficult.

---

## Asynchronous RPC

Asynchronous RPC removes strict request-reply waiting. The client sends the
request and continues working without waiting for the server response.

This helps when:

- The operation takes a long time.
- The client has other work to do.
- Multiple RPCs can run in parallel.
- A request is sent to a group of servers.

---

## Transient Messaging with Sockets

Sockets are low-level communication endpoints.

| Socket Operation | Meaning |
|---|---|
| socket | Create a communication endpoint |
| bind | Attach a local address |
| listen | Wait for incoming connection requests |
| accept | Accept a client connection |
| connect | Connect to a server |
| send | Send data |
| receive | Receive data |
| close | Release the connection |

Sockets are flexible, but they are low level and easy to use incorrectly.

---

## ZeroMQ Patterns

ZeroMQ provides higher-level asynchronous communication patterns.

| Pattern | Meaning |
|---|---|
| Request-reply | Client sends request and receives reply |
| Publish-subscribe | Publisher sends messages to subscribers interested in a topic |
| Pipeline | Producer sends tasks to workers |

These patterns simplify common messaging designs compared with raw sockets.

---

## MPI

MPI is useful when many processes need flexible message passing, especially in
high-performance computing.

It includes blocking and nonblocking operations such as send, receive,
nonblocking send, and nonblocking receive.

---

## Queue-Based Messaging

Queue-based messaging provides persistent communication using middleware queues.

| Operation | Meaning |
|---|---|
| PUT | Append a message to a queue |
| GET | Block until a queue has a message, then remove it |
| POLL | Check for a message without blocking |
| NOTIFY | Install a handler called when a message arrives |

Queue managers route messages between queues. This lets applications communicate
even if they do not run at the same time.

---

## Message Brokers

A message broker helps applications with different message formats communicate.

A broker can:

- Transform messages into the target format.
- Act as an application gateway.
- Provide routing based on subjects or topics.
- Support publish-subscribe behavior.

---

## AMQP

AMQP, the Advanced Message Queuing Protocol, is a protocol for high-level
messaging.

Its model includes:

- A stable connection.
- One-way channels.
- Sessions built from channels.
- Links that maintain state about message transfers.
- Queues and exchanges for routing messages.

AMQP is commonly associated with systems such as RabbitMQ.

---

## Multicast Communication

Multicast sends data to a group of nodes.

In distributed systems, multicast is often implemented at the application level
using an overlay network.

| Approach | Meaning |
|---|---|
| Tree-based multicast | Nodes form a tree, giving unique paths for data dissemination |
| Mesh-based multicast | Nodes form a mesh and need routing decisions |
| Flooding | Each node forwards a message to neighbors that have not seen it before |

---

## Application-Level Multicasting

In application-level multicast, the distributed system builds its own overlay
network above the physical network.

Important cost metrics include:

| Metric | Meaning |
|---|---|
| Link stress | How many times the same physical link carries the same message |
| Stretch | Ratio between overlay path delay and direct network path delay |

A good multicast overlay tries to reduce both link stress and stretch.

---

## Gossip-Based Data Dissemination

Gossip protocols spread updates in a way similar to how rumors spread.

Assumptions often include:

- Updates are initially performed at one server.
- A replica passes updates to a few neighbors.
- Propagation is lazy, not immediate.
- Eventually, every replica should receive the update.

---

## Anti-Entropy and Rumor Spreading

| Method | Meaning |
|---|---|
| Anti-entropy | Replicas regularly choose another replica and exchange differences |
| Rumor spreading | A newly updated replica tells several others about the update |

Anti-entropy can use:

- Pull: a node pulls updates from another node.
- Push: a node pushes its updates to another node.
- Push-pull: both nodes exchange updates.

Push-pull dissemination is very effective and can spread updates in logarithmic
rounds under suitable assumptions.

---

## Deleting Values in Gossip Systems

Deleting data is tricky. If a server simply removes a value, another replica may
later send the old value back again.

The solution is to represent deletion as a special update called a **death
certificate**.

A death certificate must remain long enough to reach all replicas, but it cannot
stay forever. The system must either detect global propagation or keep the
certificate for a safe maximum lifetime.

---

## Quick Summary

| Concept | Key Idea |
|---|---|
| Middleware | Common services for communication, naming, security, and scaling |
| RPC | Makes remote calls look like local procedure calls |
| Sockets | Low-level transient communication endpoints |
| Message queues | Persistent asynchronous communication |
| Broker | Translates and routes messages |
| AMQP | Standard-style protocol for message queuing |
| Multicast | Send data to a group of nodes |
| Gossip | Spread updates gradually through peer exchanges |
